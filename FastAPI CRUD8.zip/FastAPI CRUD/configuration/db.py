from sqlalchemy import create_engine, MetaData

sqlalchemy_db="mysql+pymysql://root@localhost:3306/mysql"
engine = create_engine(sqlalchemy_db)

meta = MetaData()

conn = engine.connect()